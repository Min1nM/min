package com.example.smart_house_project

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import com.example.smart_house_project.Login_class
import com.example.smart_house_project.R

class Splash_class : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.requestFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        setContentView(R.layout.loading_activity)
        Handler().postDelayed({
            startActivity(Intent(this@Splash_class, Login_class::class.java))
            finish()
        },4000)

    }
}