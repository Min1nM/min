package com.example.smart_house_project

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.util.Patterns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.lifecycle.lifecycleScope
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.gotrue.GoTrue
import io.github.jan.supabase.gotrue.gotrue
import io.github.jan.supabase.gotrue.providers.builtin.Email
import io.github.jan.supabase.postgrest.Postgrest
import kotlinx.coroutines.launch
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

class Login_class : AppCompatActivity() {
    var mail: String? = null
    var pass: String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login_activity)

        val edit_email = findViewById(R.id.email_edit) as EditText
        val edit_pass = findViewById(R.id.password_edit) as EditText
        val btnLog = findViewById(R.id.btn_log_1) as Button
        val btnReg = findViewById(R.id.btn_reg_1) as Button
        btnLog.isEnabled=false

        val client = createSupabaseClient(
            supabaseUrl = "https://frwzdxnvfejlwekzzhat.supabase.co",
            supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZyd3pkeG52ZmVqbHdla3p6aGF0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE2OTgzMTIzMTIsImV4cCI6MjAxMzg4ODMxMn0.Hcftjvx9ruC4rxSZhzjB79iU9sWVOfmkMhp87W4vBiA"
        ) {
            install(GoTrue)
            install(Postgrest)
        }
        edit_email.addTextChangedListener(object: TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
                btnLog.isEnabled=false
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0.isValidEmail()){
                    edit_email.error = null
                    btnLog.isEnabled=true
                }else{
                    edit_email.error = "Введите E-mail."
                    btnLog.isEnabled=false
                }
            }
            override fun afterTextChanged(p0: Editable?) {
                mail = edit_email.text.toString()
            }
        })
        edit_pass.addTextChangedListener(object: TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?,
                                           p1: Int, p2: Int, p3: Int) {
                btnLog.isEnabled=false
            }
            override fun onTextChanged(p0: CharSequence?,
                                       p1: Int, p2: Int, p3: Int) {
                if (p0 != null) {
                    if (p0.trim().length>0){
                        edit_pass.error = null
                        btnLog.isEnabled=true
                    }else{
                        edit_pass.error = "Нужно ввести пароль."
                    }
                }
            }
            override fun afterTextChanged(p0: Editable?) {
                pass = edit_pass.text.toString()
            }

        })
        btnLog.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {
                lifecycleScope.launch {
                client.gotrue.loginWith(Email) {
                    email = mail.toString()//"test@mail.ru"//mail.toString()
                    password =  pass.toString()//"123456"//pass.toString()
                }
                }
                val intent = Intent(applicationContext, PIN_reg_class::class.java)
                startActivity(intent)
            }
        })
        btnReg.setOnClickListener(object : View.OnClickListener {
            override fun onClick(view: View?) {
                val intent = Intent(applicationContext, Registration_class::class.java)
                startActivity(intent)
            }
        })

    }
}


fun CharSequence?.isValidEmail():Boolean{
    return !isNullOrEmpty() && Patterns
        .EMAIL_ADDRESS.matcher(this).matches()
}