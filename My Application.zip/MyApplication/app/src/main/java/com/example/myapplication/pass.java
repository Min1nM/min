package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
public class pass extends AppCompatActivity implements View.OnClickListener {
    int i = 0;
    String value = "";
    ImageView imageView, imageView1,imageView2, imageView3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pass);
        Button button1 =findViewById(R.id.b1);
        Button button2 =findViewById(R.id.b2);
        Button button3 =findViewById(R.id.b3);
        Button button4 =findViewById(R.id.b4);
        Button button5 =findViewById(R.id.b5);
        Button button6 =findViewById(R.id.b6);
        Button button7 =findViewById(R.id.b7);
        Button button8 =findViewById(R.id.b8);
        Button button9 =findViewById(R.id.b9);
         imageView3 = findViewById(R.id.imageView3);
         imageView = findViewById(R.id.imageView);
         imageView2 = findViewById(R.id.imageView2);
         imageView1 = findViewById(R.id.imageView10);

    }
    public void onClick(View v){
        switch (v.getId()){
            case R.id.b1:
                value = value + "1";
                break;
            case R.id.b2:
                value = value + "2";
                break;
            case R.id.b3:
                value = value + "3";
                break;
            case R.id.b4:
                value = value + "4";
                break;
            case R.id.b5:
                value = value + "5";
                break;
            case R.id.b6:
                value = value + "6";
                break;
            case R.id.b7:
                value = value + "7";
                break;
            case R.id.b8:
                value = value + "8";
                break;
            case R.id.b9:
                value = value + "9";
                break;
        }
        i++;
        switch(i){
            case 1:
                imageView.setImageResource(R.drawable.ellipse_57);
                imageView2.setImageResource(R.drawable.snimok);
                imageView3.setImageResource(R.drawable.snimok);
                imageView1.setImageResource(R.drawable.snimok);
            case 2:
                imageView.setImageResource(R.drawable.ellipse_57);
                imageView2.setImageResource(R.drawable.ellipse_57);
                imageView3.setImageResource(R.drawable.snimok);
                imageView1.setImageResource(R.drawable.snimok);
            case 3:
                imageView.setImageResource(R.drawable.ellipse_57);
                imageView2.setImageResource(R.drawable.ellipse_57);
                imageView3.setImageResource(R.drawable.ellipse_57);
                imageView1.setImageResource(R.drawable.snimok);
            case 4:
                imageView.setImageResource(R.drawable.ellipse_57);
                imageView2.setImageResource(R.drawable.ellipse_57);
                imageView3.setImageResource(R.drawable.ellipse_57);
                imageView1.setImageResource(R.drawable.ellipse_57);
        }
        if(i == 4){
            Intent intent = new Intent(pass.this, sozdanie.class);
            startActivity(intent);
        }
    }
}